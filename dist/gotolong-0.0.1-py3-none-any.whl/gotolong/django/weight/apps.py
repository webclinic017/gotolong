from django.apps import AppConfig


class WeightConfig(AppConfig):
    name = 'weight'
