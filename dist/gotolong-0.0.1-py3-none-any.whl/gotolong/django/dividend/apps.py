from django.apps import AppConfig


class DividendConfig(AppConfig):
    name = 'dividend'
