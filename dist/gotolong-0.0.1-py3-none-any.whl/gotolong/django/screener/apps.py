from django.apps import AppConfig


class ScreenerConfig(AppConfig):
    name = 'screener'
