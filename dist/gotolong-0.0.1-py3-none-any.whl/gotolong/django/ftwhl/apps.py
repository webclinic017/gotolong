from django.apps import AppConfig


class FtwhlConfig(AppConfig):
    name = 'ftwhl'
