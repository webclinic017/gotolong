from django.apps import AppConfig


class DemattxnConfig(AppConfig):
    name = 'demattxn'
