from django.contrib import admin

# Register your models here.
from .models import Bhav

admin.site.register(Bhav)
