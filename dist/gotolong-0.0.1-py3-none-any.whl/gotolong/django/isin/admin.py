from django.contrib import admin

# Register your models here.
from .models import Isin

# ...
admin.site.register(Isin)
