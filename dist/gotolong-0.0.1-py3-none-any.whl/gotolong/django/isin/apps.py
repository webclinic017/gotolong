from django.apps import AppConfig


class IsinConfig(AppConfig):
    name = 'isin'
