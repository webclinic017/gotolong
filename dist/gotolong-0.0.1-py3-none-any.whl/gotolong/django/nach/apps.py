from django.apps import AppConfig


class NachConfig(AppConfig):
    name = 'nach'
