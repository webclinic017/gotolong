
Google Finance doesn't work as expected in google sheet. Looking at alternatives.

NSE URL's: better to fetch for 1 working day earlier (to access archives).

52-week low and high
wget -O nse_52_wk_high_low.csv https://archives.nseindia.com/content/CM_52_wk_High_low_11082020.csv

Bhavcopy for CMP
wget -O nse_bhav.csv https://archives.nseindia.com/content/historical/EQUITIES/2020/AUG/cm12AUG2020bhav.csv.zip