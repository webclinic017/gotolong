#!/usr/bin/env bash

# to invoke report
export GOTOLONG_EXCEL=excel

gotolong_download_move.sh download yes remove yes

gotolong_all_report.sh daily