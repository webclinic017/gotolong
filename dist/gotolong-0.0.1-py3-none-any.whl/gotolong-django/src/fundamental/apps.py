from django.apps import AppConfig


class FundamentalConfig(AppConfig):
    name = 'fundamental'
