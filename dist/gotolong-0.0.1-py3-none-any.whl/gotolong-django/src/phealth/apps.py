from django.apps import AppConfig


class PhealthConfig(AppConfig):
    name = 'phealth'
