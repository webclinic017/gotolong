from django.apps import AppConfig


class DematsumConfig(AppConfig):
    name = 'dematsum'
