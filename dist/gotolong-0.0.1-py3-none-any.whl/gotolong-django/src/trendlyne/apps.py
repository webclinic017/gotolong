from django.apps import AppConfig


class TrendlyneConfig(AppConfig):
    name = 'trendlyne'
