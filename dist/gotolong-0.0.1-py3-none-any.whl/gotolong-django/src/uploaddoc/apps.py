from django.apps import AppConfig


class AmfiConfig(AppConfig):
    name = 'UploadDoc'
