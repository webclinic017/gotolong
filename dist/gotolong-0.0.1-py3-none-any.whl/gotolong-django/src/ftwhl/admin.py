from django.contrib import admin

# Register your models here.
from .models import Ftwhl

admin.site.register(Ftwhl)
