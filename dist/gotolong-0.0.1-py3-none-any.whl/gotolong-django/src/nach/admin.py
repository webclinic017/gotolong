from django.contrib import admin

# Register your models here.
from .models import Nach

admin.site.register(Nach)
